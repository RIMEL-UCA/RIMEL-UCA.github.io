# retrieval example

This is an example implementation of a client for the `key-retrieval` service, correctly implementing
incremental fetching and caching.
