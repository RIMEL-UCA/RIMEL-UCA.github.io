from django.apps import AppConfig


class AnnouncementsConfig(AppConfig):
    name = "announcements"
