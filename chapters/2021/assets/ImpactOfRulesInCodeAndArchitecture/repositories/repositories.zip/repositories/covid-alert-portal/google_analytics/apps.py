from django.apps import AppConfig


class GoogleAnalyticsConfig(AppConfig):
    name = "google_analytics"
