//
//  CovidShield.h
//  CovidShield
//
//  Created by Sergey Gavrilyuk on 2020-05-15.
//

#import <Foundation/Foundation.h>
#import <React/RCTBridgeModule.h>


@interface CovidShield : NSObject<RCTBridgeModule>

@end

