export default function ExposureCheckSchedulerAdapter(exposureCheckSchedulerAPI: any) {
  return {
    ...exposureCheckSchedulerAPI,
  };
}
