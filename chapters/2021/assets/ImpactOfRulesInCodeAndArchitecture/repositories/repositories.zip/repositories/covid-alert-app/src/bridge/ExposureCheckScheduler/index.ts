import {NativeModules} from 'react-native';

import ExposureCheckSchedulerAdapter from './ExposureCheckSchedulerAdapter';

export default ExposureCheckSchedulerAdapter(NativeModules.ExposureCheckScheduler);
