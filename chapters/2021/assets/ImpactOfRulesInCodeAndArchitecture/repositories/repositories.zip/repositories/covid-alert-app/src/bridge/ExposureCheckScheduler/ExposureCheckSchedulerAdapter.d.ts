import {ExposureCheck} from './types';

declare function ExposureCheckSchedulerAdapter(exposureCheckScheduler: ExposureCheckScheduler): ExposureCheckScheduler;

export default ExposureCheckSchedulerAdapter;
