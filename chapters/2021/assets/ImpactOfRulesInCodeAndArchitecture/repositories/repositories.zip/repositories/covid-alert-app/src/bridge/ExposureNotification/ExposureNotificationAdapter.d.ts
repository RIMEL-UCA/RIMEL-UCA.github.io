import {ExposureNotification} from './types';

declare function ExposureNotificationAdapter(exposureNotificationAPI: ExposureNotification): ExposureNotification;

export default ExposureNotificationAdapter;
